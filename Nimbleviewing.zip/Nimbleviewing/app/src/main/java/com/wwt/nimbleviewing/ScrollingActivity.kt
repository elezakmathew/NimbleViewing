package com.wwt.nimbleviewing


import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.snackbar.Snackbar
import com.wwt.nimbleviewing.databinding.ActivityScrollingBinding
import java.util.logging.Logger

class ScrollingActivity : AppCompatActivity(),VolleyCallbackInterface{

    private lateinit var recyclerView : RecyclerView
    var album = Album(1,2,"test")
    private  var albumList : List<Album> = listOf(album)



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        with(ActivityScrollingBinding.inflate(LayoutInflater.from(this), null, false)) {
            setContentView(root)
            setSupportActionBar(toolbar)
            toolbarLayout.title = this@ScrollingActivity.title
            var callbackInterface = this@ScrollingActivity
            recyclerView = included.albumList

            val albumService = AlbumService(this@ScrollingActivity,callbackInterface)
            albumService.getAlbumArt()

           fab.setOnClickListener {

               Snackbar.make(
                    fab,
                    "Display album titles and images from ${BuildConfig.BASE_URL}" ,
                    Snackbar.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onCallback(response: List<AlbumArt>) {

        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this@ScrollingActivity)
        recyclerView.layoutManager = layoutManager
        val listAdapter: AlbumListAdapter by lazy { AlbumListAdapter(response) }
        recyclerView.adapter = listAdapter

    }

}

private fun Logger.d(s: String) {

}
