package com.wwt.nimbleviewing

import android.content.Context
import android.util.Log
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.google.gson.Gson
import com.wwt.nimbleviewing.BuildConfig.ALBUM_ENDPOINT_URL
import java.io.StringReader

interface VolleyCallbackInterface{
    fun onCallback(response:List<AlbumArt>)
}
class AlbumService constructor(context: Context,callbackInterface: VolleyCallbackInterface){
    var thisContext = context
    var thisVolleyCallbackInterface = callbackInterface
    fun  getAlbumArt() {
        val queue = MySingleton.getInstance(thisContext).requestQueue
        val url = BuildConfig.ALBUM_ART_ENDPOINT_URL
        var TAG = "API ERROR"


// Request a string response from the provided URL.
        val stringRequest = StringRequest(
            Request.Method.GET, url,
            Response.Listener<String> { response ->
                var stringReader: StringReader = StringReader(response.toString())
                val albumList: List<AlbumArt> = Gson().fromJson(stringReader , Array<AlbumArt>::class.java).toList()

                thisVolleyCallbackInterface.onCallback(albumList)

            },
            Response.ErrorListener{   Log.e(TAG, "ERROR  ")})

// Add the request to the RequestQueue.
        MySingleton.getInstance(thisContext).addToRequestQueue(stringRequest)
        return
    }
}