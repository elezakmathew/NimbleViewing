package com.wwt.nimbleviewing

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import com.wwt.nimbleviewing.databinding.ListItemAlbumBinding

class AlbumListAdapter (private val albumList: List<AlbumArt>): RecyclerView.Adapter<AlbumListAdapter.AlbumViewHolder>() {
   private val data: MutableList<AlbumArt> = albumList as MutableList<AlbumArt>

  //  fun submitList(albums: List<Album>) = Unit
  class AlbumViewHolder(val itemBinding: ListItemAlbumBinding) : RecyclerView.ViewHolder(itemBinding.root)


    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): AlbumViewHolder {

        val itemBinding = ListItemAlbumBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return AlbumViewHolder(itemBinding)
    }

    override fun getItemCount(): Int = albumList.size


    override fun onBindViewHolder(holder: AlbumViewHolder, position: Int) {
        with(holder){
            with(albumList[position]){
                itemBinding.albumArtText.text = this.title.replace("e","")

               Picasso.get().load(this.url).fit().into(itemBinding.albumArt)

            }
        }
    }


}


